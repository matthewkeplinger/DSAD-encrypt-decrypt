/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsad;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class test1 {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        int delta = 0x9E3779B9;

        // users profiles 
        ArrayList<int[]> profiles = new ArrayList();
        int[] p1 = new int[]{0, 3, 4, 132, 6, 135, 9, 15, 27, 156, 29, 158, 31, 33, 163, 166, 167, 42, 175, 47, 49, 181, 54, 55, 184, 186, 187, 60, 188, 61, 63, 193, 72, 73, 74, 75, 206, 79, 209, 212, 215, 88, 90, 218, 91, 92, 94, 96, 224, 227, 229, 231, 238, 110, 112, 115, 116, 119, 248, 122, 251, 252, 124, 127};
        int[] p2 = new int[]{128, 1, 129, 3, 132, 135, 136, 9, 137, 10, 12, 15, 145, 146, 23, 152, 24, 156, 159, 161, 171, 44, 45, 175, 47, 176, 49, 179, 180, 53, 55, 184, 57, 58, 190, 195, 70, 71, 72, 207, 80, 84, 214, 87, 215, 89, 90, 92, 224, 96, 98, 226, 99, 105, 106, 235, 238, 112, 114, 243, 244, 120, 121, 125};
        int[] p3 = new int[]{2, 131, 3, 4, 133, 135, 136, 10, 11, 15, 143, 145, 17, 21, 151, 25, 157, 158, 33, 164, 37, 38, 172, 173, 45, 174, 51, 183, 56, 58, 187, 64, 192, 196, 70, 72, 204, 207, 82, 211, 84, 88, 89, 217, 90, 91, 92, 93, 95, 224, 97, 226, 232, 104, 110, 241, 118, 246, 119, 120, 249, 250, 122, 123};
        int[] p4 = new int[]{1, 129, 3, 133, 135, 14, 144, 145, 19, 147, 151, 153, 154, 155, 35, 164, 36, 165, 40, 41, 43, 172, 45, 174, 51, 53, 181, 54, 190, 191, 194, 66, 195, 198, 199, 72, 73, 203, 206, 79, 81, 82, 83, 212, 84, 213, 90, 224, 227, 229, 104, 105, 106, 108, 238, 241, 114, 116, 245, 246, 119, 121, 249, 253};
        int[] p5 = new int[]{0, 130, 132, 134, 7, 139, 12, 141, 145, 147, 148, 21, 22, 150, 151, 26, 154, 158, 159, 163, 165, 41, 170, 43, 171, 44, 46, 47, 176, 50, 54, 56, 57, 186, 59, 188, 61, 62, 66, 67, 195, 68, 198, 72, 74, 203, 207, 80, 210, 84, 215, 87, 218, 92, 96, 100, 101, 230, 109, 237, 245, 118, 124, 126};
        int[] p6 = new int[]{1, 3, 6, 8, 138, 13, 143, 17, 145, 18, 22, 153, 25, 154, 28, 156, 158, 36, 37, 38, 40, 42, 174, 51, 57, 185, 186, 187, 188, 60, 62, 66, 69, 201, 207, 208, 81, 212, 84, 86, 215, 218, 221, 94, 95, 96, 99, 228, 229, 231, 105, 108, 241, 242, 243, 244, 117, 247, 120, 250, 123, 252, 253, 125};
        int[] p7 = new int[]{130, 131, 5, 135, 136, 9, 138, 14, 143, 144, 17, 145, 151, 152, 153, 156, 34, 35, 167, 42, 43, 172, 44, 45, 174, 47, 177, 49, 52, 183, 56, 57, 187, 63, 64, 206, 78, 79, 84, 212, 214, 86, 216, 220, 94, 223, 225, 104, 232, 105, 233, 107, 108, 237, 110, 111, 112, 113, 241, 242, 116, 245, 120, 125};
        profiles.add(p1);
        profiles.add(p2);
        profiles.add(p3);
        profiles.add(p4);
        profiles.add(p5);
        profiles.add(p6);
        profiles.add(p7);

// scanner for user input
        Scanner s = new Scanner(System.in);
        // place holders for user inputs
        int userProfileSelection = 1;
        int ecbCBC = 1;
        int encryptDecrypt = 1;
        String fileKey = "";
        String fileBinary = "";
        String fileIV = "";

        System.out.println("Select a User Profile (1-7): ");
        userProfileSelection = s.nextInt();
        System.out.println();
        System.out.println("Please input directory for the file you want Crypted: ");
        fileBinary = s.next();
        System.out.println("Please input directory for key: ");
        fileKey = s.next();

        // loads in files
        InputStream binaryStream = new FileInputStream(fileBinary);
        InputStream keyStream = new FileInputStream(fileKey);

        // loads message in byte array and an int array
        byte[] message = new byte[binaryStream.available()];
        for (int i = 0; i < message.length; i++) {
            message[i] = (byte) binaryStream.read();
        }
        int[] intMessage = new int[message.length];
        for (int i = 0; i < intMessage.length; i++) {
            intMessage[i] = message[i];
        }

        //loads key in byte array and an int array
        byte[] key = new byte[keyStream.available()];
        for (int i = 0; i < key.length; i++) {
            key[i] = (byte) keyStream.read();
        }
        int[] intKey = new int[key.length];
        for (int i = 0; i < intKey.length; i++) {
            intKey[i] = key[i];
        }

        System.out.println("~~~Encryption~~~");
        System.out.println("ECB: 1\nCBC:2 ");
        System.out.println("Select mode of encryption(1-2): ");
        ecbCBC = s.nextInt();
        switch (ecbCBC) {
            case 1: {
                int[] messageEncrypted = TinyE.encryptECB(intMessage, intKey, delta);
                byte[] encryptedBytes = new byte[messageEncrypted.length];
                for (int i = 0; i < encryptedBytes.length; i++) {
                    encryptedBytes[i] = (byte) messageEncrypted[i];
                }
                String sMessageEncrypted = "";

                for (int i = 0; i < messageEncrypted.length; i++) {
                    sMessageEncrypted += String.format("%8s", Integer.toBinaryString(messageEncrypted[i] & 0xFF)).replace(' ', '0');
                }
                int[] binaryEncrypted = new int[sMessageEncrypted.length()];
                for (int i = 0; i < binaryEncrypted.length; i++) {
                    binaryEncrypted[i] = Integer.parseInt(Character.toString(sMessageEncrypted.charAt(i)));
                }

                int[] messageEncoded = Encode.encode(profiles.get(userProfileSelection), binaryEncrypted);
                System.out.println("Your Encrypted Message is: \n");
                for (int i = 0; i < messageEncrypted.length; i++) {
                    System.out.print(String.format("%8s", Integer.toBinaryString(messageEncrypted[i] & 0xFF)).replace(' ', '0'));
                }
                System.out.println("\nYour Encrypted Message Encoded is: \n");
                for (int i = 0; i < messageEncoded.length; i++) {
                    System.out.print(messageEncoded[i]);
                }
                System.out.println("\noutput files created\n");
                OutputStream encryptedFile = new FileOutputStream("EncryptedFile.dat");
                encryptedFile.write(encryptedBytes);
                OutputStream encodedFile = new FileOutputStream("encoded.dat");
                for (int i = 0; i < messageEncoded.length; i++) {
                    encodedFile.write(messageEncoded[i]);
                }
                encryptedFile.close();
                encodedFile.close();
                break;
            }
            case 2: {
                System.out.println("Please input directory for iv: ");
                fileIV = s.next();
                InputStream ivStream = new FileInputStream(fileIV);

                // loads message in byte array and an int array
                byte[] iv = new byte[ivStream.available()];
                for (int i = 0; i < iv.length; i++) {
                    iv[i] = (byte) ivStream.read();
                }
                int[] intIV = new int[iv.length];
                for (int i = 0; i < intIV.length; i++) {
                    intIV[i] = iv[i];
                    int[] messageEncrypted = TinyE.encryptCBC(intMessage, intKey, delta, intIV);

                    byte[] encryptedBytes = new byte[messageEncrypted.length];
                    for (; i < encryptedBytes.length; i++) {
                        encryptedBytes[i] = (byte) messageEncrypted[i];
                    }

                    String sMessageEncrypted = "";

                    for (; i < messageEncrypted.length; i++) {
                        sMessageEncrypted += String.format("%8s", Integer.toBinaryString(messageEncrypted[i] & 0xFF)).replace(' ', '0');
                    }
                    int[] binaryEncrypted = new int[sMessageEncrypted.length()];
                    for (; i < binaryEncrypted.length; i++) {
                        binaryEncrypted[i] = Integer.parseInt(Character.toString(sMessageEncrypted.charAt(i)));
                    }

                    int[] messageEncoded = Encode.encode(profiles.get(userProfileSelection), binaryEncrypted);

                    System.out.println("Your Encrypted Message is: \n");
                    for (; i < messageEncrypted.length; i++) {
                        System.out.print(String.format("%8s", Integer.toBinaryString(messageEncrypted[i] & 0xFF)).replace(' ', '0'));
                    }
                    System.out.println("\nYour Encrypted Message Encoded is: \n");
                    for (; i < messageEncoded.length; i++) {
                        System.out.print(messageEncoded[i]);
                    }
                    System.out.println("\noutput files created\n");
                    OutputStream encryptedFile = new FileOutputStream("EncryptedFile.dat");
                    OutputStream encodedFile = new FileOutputStream("encoded.dat");
                    for (; i < messageEncoded.length; i++) {
                        encodedFile.write(messageEncoded[i]);
                    }
                    encryptedFile.write(encryptedBytes);
                    encryptedFile.close();
                    encodedFile.close();
                    
                    break;
                }
            }
        }

    }
}
