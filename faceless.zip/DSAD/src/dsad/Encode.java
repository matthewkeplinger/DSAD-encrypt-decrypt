/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsad;

/**
 *
 * @author nicho
 */
public class Encode {
    public static int[]encode(int[]profile, int[] signal){
        int[] ans = new int[signal.length];
        
        for(int i =0;i<profile.length;i++){
            if(signal[i]==1){
                ans[i]=profile[i];
            }
            else
                ans[i]=(-profile[i]);
        }
        return ans;
        
    
    }    
    public static int[] decode( int[] profile, int[] encodedSignal){
        int[] binarySignal = new int[encodedSignal.length];
        for(int i=0;i<encodedSignal.length;i++){
            if(encodedSignal[i]<0)
                binarySignal[i]=0;
            else
                binarySignal[i]=1;
        }
        
        
        return binarySignal;
    }
}
