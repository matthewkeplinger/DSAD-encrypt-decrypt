/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nicho
 */

import java.io.*;
        
public class generateFiles {
    
     public static void main(String... aArgs) throws FileNotFoundException, IOException {
         byte[] signal = new byte[32];
        signal[0]= (byte)0b10100011;
        signal[1]= (byte)0b00000000;
        signal[2]= (byte)0b00000000;
        signal[3]= (byte)0b00001000;
        signal[4]= (byte)0b10100011;
        signal[5]= (byte)0b00000000;
        signal[6]= (byte)0b00000000;
        signal[7]= (byte)0b00001000;
        signal[8]= (byte)0b10100011;
        signal[9]= (byte)0b00110000;
        signal[10]= (byte)0b00011100;
        signal[11]= (byte)0b11111000;
        signal[12]= (byte)0b10100011;
        signal[13]= (byte)0b01110000;
        signal[14]= (byte)0b00001110;
        signal[15]= (byte)0b00111000;        
        signal[16]= (byte)0b10100011;
        signal[17]= (byte)0b00011000;
        signal[18]= (byte)0b01000000;
        signal[19]= (byte)0b00111000;
        signal[20]= (byte)0b10000011;
        signal[21]= (byte)0b00111000;
        signal[22]= (byte)0b11001111;
        signal[23]= (byte)0b00101000;         
        signal[24]= (byte)0b10000011;
        signal[25]= (byte)0b01110000;
        signal[26]= (byte)0b01110111;
        signal[27]= (byte)0b00111110;
        signal[28]= (byte)0b11111011;
        signal[29]= (byte)0b00011100;
        signal[30]= (byte)0b00111100;
        signal[31]= (byte)0b01111000;
        byte [] iv= new byte [8];
        iv[0] = (byte)0b01110101;
        iv[1] = (byte)0b01011101;
        iv[2] = (byte)0b01110011;
        iv[3] = (byte)0b11111100;
        iv[4] = (byte)0b11100011;
        iv[5] = (byte)0b00011101;
        iv[6] = (byte)0b01000001;
        iv[7] = (byte)0b01110000;
        
        byte [] k = new byte [16];
        k[0] = (byte)0b01000101;
        k[1] = (byte)0b01011101;
        k[2] = (byte)0b00010011;
        k[3] = (byte)0b01000100;
        k[4] = (byte)0b01100011;
        k[5] = (byte)0b01111101;
        k[6] = (byte)0b01001101;
        k[7] = (byte)0b01111101;
        k[8] = (byte)0b01001101;
        k[9] = (byte)0b00000101;
        k[10] = (byte)0b11110101;
        k[11] = (byte)0b01001111;
        k[12] = (byte)0b01111101;
        k[13] = (byte)0b01110101;
        k[14] = (byte)0b11111101;
        k[15] = (byte)0b01110111;
         
         
         DataOutputStream key1 = new DataOutputStream(new FileOutputStream("key.dat"));
         DataOutputStream iv1 = new DataOutputStream(new FileOutputStream("iv.dat"));
         DataOutputStream out = new DataOutputStream(new FileOutputStream("signal.dat"));
         out.write(signal);
         key1.write(k);
         iv1.write(iv);
         iv1.flush();
         iv1.close();
         key1.flush();
         key1.close();
         out.flush();
         out.close();
         
     }
}
