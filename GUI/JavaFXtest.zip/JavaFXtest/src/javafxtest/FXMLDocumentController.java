/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javafxtest;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleGroup;

/**
 *
 * @author Lisa M Futch
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    
     @FXML
    private Label lbl1;

    @FXML
    private Label lbl2;

    @FXML
    private void btnEncodeDecode(ActionEvent event) {
        lbl2.setText("Futch!");
    
    }
    @FXML
    private void btnMethod(ActionEvent event) {
        lbl1.setText("lisa!");
    
    }
    @FXML
    private void buttonAction(ActionEvent event) {
        int x=3;
        int y=2;
        double z = x*y;
        System.out.println(x + " + "+ y + " = "+ z);
        label.setText("Hello World!");
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
