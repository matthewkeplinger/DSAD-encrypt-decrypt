/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsad;

public class test {

    public static void main(String[] args) {
        String StringKey = "1100100101010011011010001111010001110100110100101011101011111001101000100010000011100010000100010111000111100001100000101001011";
        String StringSignal = "0001101001001010111111000001010000100000110100011101110011010011010001110000110001010010001001110110111111011111101110111111110111101011011001100001010110111001010100101111001111001001001100100001000100101110010011110010100010100010010100001110000100110011";
        int [] profile = profileGenerator.generate();
        // divviding the 256 bit string into 4 64bit blocks
        String block1 = StringSignal.substring(0, 64);
        String block2 = StringSignal.substring(64, 128);
        String block3 = StringSignal.substring(128, 192);
        String block4 = StringSignal.substring(192, 256);
        
        // turning the string into a byte array
        byte[] bl1 = new byte[block1.length()];
        for (int i = 0; i < block1.length(); i++) {
            bl1[i] = block1.charAt(i) == '1' ? (byte) 1 : (byte) 0;
        }
        // turning the string into a byte array
        byte[] bl2 = new byte[block2.length()];
        for (int i = 0; i < block2.length(); i++) {
            bl2[i] = block2.charAt(i) == '1' ? (byte) 1 : (byte) 0;
        }
        // turning the string into a byte array
        byte[] bl3 = new byte[block3.length()];
        for (int i = 0; i < block3.length(); i++) {
            bl3[i] = block3.charAt(i) == '1' ? (byte) 1 : (byte) 0;
        }
        // turning the string into a byte array
        byte[] bl4 = new byte[block4.length()];
        for (int i = 0; i < block4.length(); i++) {
            bl4[i] = block4.charAt(i) == '1' ? (byte) 1 : (byte) 0;
        }
   
        // turing the binary signal into a byte array
        byte[] signal = new byte[StringSignal.length()];
        for (int i = 0; i < StringSignal.length(); i++) {
            signal[i] = StringSignal.charAt(i) == '1' ? (byte) 1 : (byte) 0;
        }
        // turing the key into a byte array;
        byte[] key = new byte[StringKey.length()]; 
        for (int i = 0; i < StringKey.length(); i++) {
            key[i] = StringKey.charAt(i) == '1' ? (byte) 1 : (byte) 0;
        }
        TEA t = new TEA(key);
        // encrypted block1
        byte[] cb1 = t.encrypt(bl1);
        // decrypted encrypted block 1
        byte[] db1 = t.decrypt(cb1);

        // print the orginal string format of the key
        System.out.println("key: "+StringKey);
        // print the orignal string format of the signal
        System.out.println("Signal: "+StringSignal);   
        // string block
        System.out.println("Block1  "+block1);  
        System.out.println("Block2: "+block2);  
        System.out.println("Block3: "+block3);  
        System.out.println("Block4: "+block4); 
        // this is the byte array key
        System.out.print("byteKey: ");
        for (int i = 0; i < key.length; i++) {
            System.out.print(Integer.toBinaryString(key[i]));
        }
        // byte array signal
        System.out.print("\nbyteSignal: ");
        for (int i = 0; i < signal.length; i++) {
            System.out.print(Integer.toBinaryString(signal[i]));
        }
        System.out.print("\ncryptedSignal: ");
        for (int i = 0; i < cb1.length; i++) {
            System.out.print(Integer.toBinaryString(cb1[i]));
        }
        System.out.println("\nuncryptedBlock1  "+block1);
        System.out.print("\ndecryptedblock1: ");
        for (int i = 0; i < db1.length; i++) {
            System.out.print(Integer.toBinaryString(db1[i]));
        }
     
        
    }

}
